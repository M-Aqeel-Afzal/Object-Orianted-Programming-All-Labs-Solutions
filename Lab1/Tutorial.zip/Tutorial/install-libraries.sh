#!/bin/bash
sudo apt-get install libgtest-dev
sudo apt-get install cmake 
cd /usr/src/gtest
sudo cmake CMakeLists.txt
sudo make
sudo cp *.a /usr/lib
